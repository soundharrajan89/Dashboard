export function Page3() {
  return <h1>Page-3</h1>
}
