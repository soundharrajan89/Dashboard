import { render, screen } from "@testing-library/react";
import { Home } from "./Home";

describe("when rendered with a `name` prop", () => {
  it("should paste it into the greetings text", () => {
    render(<Home />); 
    expect(
      screen.getByText(/Home/)
    ).toBeInTheDocument();
  });
});